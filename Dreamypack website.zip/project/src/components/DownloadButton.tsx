import React, { useState } from 'react';
import { Download, ChevronDown } from 'lucide-react';

const versions = [
  { version: '1.21.4', date: '2024-12-15', url: '#' },
  { version: '1.20.4', date: '2023-02-01', url: '#' },
];

export function DownloadButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block">
      <div className="flex">
        <button 
          className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-4 px-8 rounded-l-lg
                   flex items-center justify-center gap-2 transition-all"
          onClick={() => window.location.href = versions[0].url}
        >
          <Download size={24} />
          Download Latest
        </button>
        <button
          className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-4 px-4 rounded-r-lg
                   border-l border-purple-400 transition-all"
          onClick={() => setIsOpen(!isOpen)}
        >
          <ChevronDown size={24} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {isOpen && (
        <div className="absolute mt-2 w-full bg-gray-800 rounded-lg shadow-xl z-50 overflow-hidden">
          {versions.map((version, index) => (
            <a
              key={index}
              href={version.url}
              className="block px-4 py-3 text-gray-200 hover:bg-gray-700 transition-colors"
            >
              <div className="font-semibold">Version {version.version}</div>
              <div className="text-sm text-gray-400">{version.date}</div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}