import React from 'react';

export function InstallGuide() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-16">
      <h2 className="text-2xl font-bold text-purple-400 mb-8">Installation Guide</h2>
      <div className="bg-gray-800 rounded-lg p-8">
        <ol className="text-gray-300 space-y-4">
          <li>1. Download the Dreamypack resource pack</li>
          <li>2. Open Minecraft Java Edition</li>
          <li>3. Click on "Options" → "Resource Packs"</li>
          <li>4. Click "Open Resource Pack Folder"</li>
          <li>5. Move the downloaded zip file into this folder</li>
          <li>6. Select Dreamypack in the game and click "Done"</li>
          <li>The game may show a warning that the pack is incompatible; you can ignore that warning.</li>
        </ol>
      </div>
    </div>
  );
}