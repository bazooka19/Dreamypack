import React from 'react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400 py-8 text-center">
      <p>© 2024 Dreamypack. Made for Minecraft Java Edition.
      Created by Cheezie and Slybazooka19</p>
    </footer>
  );
}