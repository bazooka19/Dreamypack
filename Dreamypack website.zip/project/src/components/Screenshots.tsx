import React from 'react';

export function Screenshots() {
  const screenshots = [
    {
      url: "https://images.unsplash.com/photo-1627856014754-2907e2355d54?auto=format&fit=crop&q=80",
      caption: "Custom textures and animations"
    },
    {
      url: "https://images.unsplash.com/photo-1627856014772-e11f85d92db1?auto=format&fit=crop&q=80",
      caption: "Unique mob skins"
    },
    {
      url: "https://images.unsplash.com/photo-1627856014789-27c1c4b5fd0f?auto=format&fit=crop&q=80",
      caption: "Special effects"
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-16">
      <h2 className="text-2xl font-bold text-purple-400 mb-8">Screenshots</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {screenshots.map((screenshot, index) => (
          <div key={index} className="bg-gray-800 rounded-lg overflow-hidden">
            <img
              src={screenshot.url}
              alt={screenshot.caption}
              className="w-full h-48 object-cover hover:opacity-75 transition-opacity"
            />
            <p className="p-4 text-gray-300 text-center">{screenshot.caption}</p>
          </div>
        ))}
      </div>
    </div>
  );
}