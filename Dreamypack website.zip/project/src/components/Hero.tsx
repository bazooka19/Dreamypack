import React from 'react';
import { Box } from 'lucide-react';
import { DownloadButton } from './DownloadButton';

export function Hero() {
  return (
    <div className="relative h-[60vh] flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1607988795691-3d0147b43231?auto=format&fit=crop&q=80")'
        }}
      />
      <div className="relative text-center px-4">
        <div className="flex items-center justify-center mb-6">
          <Box size={48} className="text-purple-400" />
        </div>
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">Dreamypack</h1>
        <p className="text-purple-300 text-xl mb-8">A Dreamybull Minecraft texture pack</p>
        <DownloadButton />
        <p className="text-gray-400 mt-4">For Java version 1.21.4</p>
      </div>
    </div>
  );
}