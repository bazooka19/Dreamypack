import React from 'react';

export function Features() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-16">
      <div className="grid md:grid-cols-2 gap-12">
        <div className="bg-gray-800 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-purple-400 mb-4">Features</h2>
          <ul className="text-gray-300 space-y-2">
            <li>• Custom sound effects and Perrell's face</li>
            <li>• Ambussing sound effects</li>
            <li>• All new music disc</li>
            <li>• Different paintings</li>
            <li>• Dont look at the moon</li>
            <li>• So much more</li>
          </ul>
        </div>
        <div className="bg-gray-800 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-purple-400 mb-4">Description</h2>
          <p className="text-gray-300">
            The Dreamypack is a simple and funny element to add to your Minecraft world, perfect for background ambiance or pranking your friends. Upon loading the pack, you may not notice anything at first. It is designed to be subtle, but before you know it, you might run past a sheep making a questionable noise, or a zombie might try to attack you with a familiar face. This is the perfect pack for those moments in Minecraft where you forget about it, only to be hilariously reminded that it’s part of your world.
          </p>
        </div>
      </div>
    </div>
  );
}