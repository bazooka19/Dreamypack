import React from 'react';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Screenshots } from './components/Screenshots';
import { InstallGuide } from './components/InstallGuide';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-gray-900">
      <Hero />
      <Features />
      <Screenshots />
      <InstallGuide />
      <Footer />
    </div>
  );
}

export default App;